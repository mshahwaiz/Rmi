/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmi.server;

import java.io.Serializable;

/**
 *
 * @author BSE193115
 */
public class cars implements Serializable {

    String name;
    String model;
    String price;

    public cars(String name, String model, String price) {
        this.name = name;
        this.model = model;
        this.price = price;
    }

   

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
     public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
    
}
