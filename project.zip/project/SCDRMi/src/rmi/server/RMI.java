/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package rmi.server;

import java.net.MalformedURLException;
import java.rmi.AccessException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Windows 10
 */
public class RMI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            crud a=new database();
            crud stub = (crud) UnicastRemoteObject.exportObject(a,0);

            // Bind the remote object's stub in the registry
            Registry registry = LocateRegistry.createRegistry(1140);
            registry.bind("insert", stub);

          
            
            
            System.out.println(" Server ready");
           
            
        } catch (RemoteException ex) {
            Logger.getLogger(RMI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (AlreadyBoundException ex) {
            Logger.getLogger(RMI.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            crud edtt=new database();
            crud st = (crud) UnicastRemoteObject.exportObject(edtt,0);

            // Bind the remote object's st in the registry
            Registry registry1 = LocateRegistry.createRegistry(1150);
            registry1.bind("edits", st);
            
            
            System.out.println(" Server ready");
           
            
        } catch (RemoteException ex) {
            Logger.getLogger(RMI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (AlreadyBoundException ex) {
            Logger.getLogger(RMI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
