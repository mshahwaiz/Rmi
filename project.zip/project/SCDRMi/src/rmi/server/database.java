/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmi.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author BSE193115
 */
public class database implements crud {
        Connection con;
        cars c;
        
    public database(){
        
        try {
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/scddb", "root","");
            System.out.println("conection establisted");
        } catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    public void add(cars c)
    {
        String query= "INSERT INTO cars(name,model,price) values"+"('"+c.getName()+"','"+c.getModel()+"','"+c.getPrice()+"')";
        try {
            Statement st=con.createStatement();
            int r=st.executeUpdate(query);
            if(r!=0)
            {
              JOptionPane.showMessageDialog(null, "Record Inserted!!!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
        @Override
    public void edit(cars c)
    {
        
        String qurey="Update cars set name='"+c.name+"',model='"+c.getModel()+"',price='"+c.getPrice()+"' where id='"+3+"'";
       try {
            Statement st=con.createStatement();
            int r=st.executeUpdate(qurey);
            if(r!=0)
            {
              JOptionPane.showMessageDialog(null, "Record Updated!!!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
