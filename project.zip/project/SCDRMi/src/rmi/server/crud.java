/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmi.server;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author BSE193115
 */
public interface crud extends Remote {
    public void add(cars c) throws RemoteException;
    public void edit(cars c) throws RemoteException;
}
