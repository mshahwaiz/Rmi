/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package client;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
//import rmi.server.Adder;
import rmi.server.crud;
import rmi.server.cars;

/**
 *
 * @author Windows 10
 */
public class ClientRequest {
     public static String name;
     public static String model;
     public static String price;
     

    public ClientRequest(String name, String model, String price) {
        this.name = name;
        this.model = model;
        this.price = price;
    }
    
   
      public void insert(){
       try {
            
              Registry registry = LocateRegistry.getRegistry(1140);
            crud stub = (crud) registry.lookup("insert");
            
             cars c=new cars(name,model,price);
             System.out.println("Record Added "+name+" "+ model+" "+price);
             stub.add(c);
            
          
          
          } catch (NotBoundException ex) {
              Logger.getLogger(ClientRequest.class.getName()).log(Level.SEVERE, null, ex);
          }catch (RemoteException ex) {
              Logger.getLogger(ClientRequest.class.getName()).log(Level.SEVERE, null, ex);
          }
      
      }
      
       public void editt(){
       try {
            
              Registry registry1 = LocateRegistry.getRegistry(1150);
            crud st = (crud) registry1.lookup("edits");
            
             cars cm=new cars(name,model,price);
             System.out.println("Record Updated "+name+" "+ model+" "+price);
             st.edit(cm);
            
          
          
          } catch (NotBoundException ex) {
              Logger.getLogger(ClientRequest.class.getName()).log(Level.SEVERE, null, ex);
          }catch (RemoteException ex) {
              Logger.getLogger(ClientRequest.class.getName()).log(Level.SEVERE, null, ex);
          }
      
      }
}
